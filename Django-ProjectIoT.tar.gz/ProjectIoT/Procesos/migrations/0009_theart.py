# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0008_remove_tcompra_titular'),
    ]

    operations = [
        migrations.CreateModel(
            name='THeart',
            fields=[
                ('idHeart', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('FechaTiempo', models.DateField(verbose_name=b'FechaTiempo:')),
                ('Beat', models.DecimalField(default=0, max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idHeart'],
                'verbose_name': 'Heart',
                'verbose_name_plural': 'Hearts',
            },
        ),
    ]
