# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0004_auto_20180208_1747'),
    ]

    operations = [
        migrations.CreateModel(
            name='TCompra',
            fields=[
                ('idCompra', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('FechaCompra', models.DateField(verbose_name=b'Fecha compra:')),
                ('NroDocumento', models.CharField(max_length=10, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Punitario', models.DecimalField(default=0, max_digits=15, decimal_places=2)),
                ('IngresoTransferencia', models.DecimalField(max_digits=15, decimal_places=3)),
                ('IngresoTransferenciaContable', models.DecimalField(max_digits=15, decimal_places=3)),
                ('NotaCredito', models.CharField(max_length=20, null=True, verbose_name=b'NotaCredito:', blank=True)),
                ('TransporteGalon', models.CharField(max_length=10, null=True, verbose_name=b'TransporteGalon:', blank=True)),
                ('Observacion', models.CharField(max_length=100, null=True, verbose_name=b'Observacion', blank=True)),
                ('Igv', models.DecimalField(default=18, verbose_name=b'IGV', max_digits=15, decimal_places=2)),
                ('Percepcion', models.DecimalField(default=1, verbose_name=b'Percepcion', max_digits=15, decimal_places=2)),
                ('FechaPago', models.DateField(verbose_name=b'Fecha compra:')),
                ('NroCheque', models.CharField(max_length=20, null=True, verbose_name=b'NroCheque:', blank=True)),
                ('ReporteDiario', models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario')),
                ('Tanque', models.ForeignKey(verbose_name=b'Tanque', to='Procesos.Tanque')),
                ('Titular', models.ForeignKey(verbose_name=b'Id Titular', to='Procesos.TTitular', null=True)),
            ],
            options={
                'ordering': ['idCompra'],
                'verbose_name': 'COMPRA',
                'verbose_name_plural': 'COMPRAS',
            },
        ),
    ]
