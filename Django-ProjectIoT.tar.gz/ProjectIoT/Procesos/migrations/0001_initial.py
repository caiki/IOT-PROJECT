# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Grifo',
            fields=[
                ('idGrifo', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('NombreEstacion', models.CharField(max_length=50, null=True, verbose_name=b'NombreEstacion:', blank=True)),
                ('Administrador', models.CharField(max_length=50, null=True, verbose_name=b'Administrador:', blank=True)),
            ],
            options={
                'ordering': ['idGrifo'],
                'verbose_name': 'Grifo',
                'verbose_name_plural': 'Grifos',
            },
        ),
        migrations.CreateModel(
            name='Inicio',
            fields=[
                ('idInicio', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('aux1', models.CharField(max_length=20, null=True, verbose_name=b'aux1:', blank=True)),
                ('aux2', models.CharField(max_length=20, null=True, verbose_name=b'aux2:', blank=True)),
                ('Grifo', models.ForeignKey(verbose_name=b'Id Grifo', to='Procesos.Grifo')),
            ],
            options={
                'ordering': ['idInicio'],
                'verbose_name': 'Inicio',
                'verbose_name_plural': 'Inicios',
            },
        ),
        migrations.CreateModel(
            name='LecturaContometro',
            fields=[
                ('idLectura', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('ValorContometroFinal1', models.DecimalField(max_digits=15, decimal_places=3)),
                ('ValorContometroFinal2', models.DecimalField(max_digits=15, decimal_places=3)),
            ],
            options={
                'ordering': ['idLectura'],
                'verbose_name': 'Lectura de Contometro',
                'verbose_name_plural': 'Lecturas de Contometro',
            },
        ),
        migrations.CreateModel(
            name='PrecioCombustible',
            fields=[
                ('idPrecioComb', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('Fecha', models.DateTimeField(auto_now=True, verbose_name=b'Fecha:')),
                ('PrecioAnterior', models.DecimalField(default=0, max_digits=15, decimal_places=3)),
                ('PrecioActual', models.DecimalField(max_digits=15, decimal_places=3)),
            ],
            options={
                'ordering': ['idPrecioComb'],
                'verbose_name': 'Precio Combustible',
                'verbose_name_plural': 'Precios Combustible',
            },
        ),
        migrations.CreateModel(
            name='Surtidor',
            fields=[
                ('idSurtidor', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('NombreSurtidor', models.CharField(max_length=50, null=True, verbose_name=b'NombreSurtidor:', blank=True)),
                ('Grifo', models.ForeignKey(verbose_name=b'Id Grifo', to='Procesos.Grifo')),
            ],
            options={
                'ordering': ['idSurtidor'],
                'verbose_name': 'Surtidor',
                'verbose_name_plural': 'Surtidores',
            },
        ),
        migrations.CreateModel(
            name='Tanque',
            fields=[
                ('idTanque', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('Nombre', models.CharField(max_length=15, null=True, verbose_name=b'Nombre:', blank=True)),
            ],
            options={
                'ordering': ['idTanque'],
                'verbose_name': 'Tanque',
                'verbose_name_plural': 'Tanques',
            },
        ),
        migrations.CreateModel(
            name='TCombustible',
            fields=[
                ('idCombustible', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('NombreCombustible', models.CharField(max_length=20, null=True, verbose_name=b'NombreCombustible:', blank=True)),
            ],
            options={
                'ordering': ['idCombustible'],
                'verbose_name': 'TCombustible',
                'verbose_name_plural': 'TCombustibles',
            },
        ),
        migrations.CreateModel(
            name='Tdeposito',
            fields=[
                ('idDeposito', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('NroBoucher', models.CharField(max_length=45, null=True, verbose_name=b'NroBoucher:', blank=True)),
                ('Concepto', models.CharField(max_length=100, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Monto', models.DecimalField(max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idDeposito'],
                'verbose_name': 'Deposito',
                'verbose_name_plural': 'Depositos',
            },
        ),
        migrations.CreateModel(
            name='TDetalleCreditos',
            fields=[
                ('idDetalleCredito', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('NroVale', models.CharField(max_length=10, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Concepto', models.CharField(max_length=100, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Monto', models.DecimalField(max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idDetalleCredito'],
                'verbose_name': 'Detalle Credito',
                'verbose_name_plural': 'Detalles Credito',
            },
        ),
        migrations.CreateModel(
            name='TDetalleDescuento',
            fields=[
                ('idDetalleDescuento', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('NroVale', models.CharField(max_length=10, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Concepto', models.CharField(max_length=100, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Monto', models.DecimalField(max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idDetalleDescuento'],
                'verbose_name': 'Detalle Descuento',
                'verbose_name_plural': 'Detalles Descuento',
            },
        ),
        migrations.CreateModel(
            name='TDetalleGastos',
            fields=[
                ('idDetalleGasto', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('NroVale', models.CharField(max_length=10, null=True, verbose_name=b'Nro Vale:', blank=True)),
                ('Concepto', models.CharField(max_length=100, null=True, verbose_name=b'Concepto:', blank=True)),
                ('Monto', models.DecimalField(max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idDetalleGasto'],
                'verbose_name': 'Detalle Gasto',
                'verbose_name_plural': 'Detalles Gastos',
            },
        ),
        migrations.CreateModel(
            name='TDetalleSerafin',
            fields=[
                ('idDetalleSerafin', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('NroVale', models.CharField(max_length=10, null=True, verbose_name=b'Nro Vale:', blank=True)),
                ('Cantidad', models.DecimalField(max_digits=15, decimal_places=2)),
                ('Observacion', models.CharField(max_length=100, null=True, verbose_name=b'Observacion:', blank=True)),
                ('Monto', models.DecimalField(max_digits=15, decimal_places=2)),
                ('Combustible', models.ForeignKey(verbose_name=b'Id Combustible', to='Procesos.TCombustible')),
            ],
            options={
                'ordering': ['idDetalleSerafin'],
                'verbose_name': 'Detalle Serafin',
                'verbose_name_plural': 'Detalles Serafin',
            },
        ),
        migrations.CreateModel(
            name='TManguera',
            fields=[
                ('idManguera', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('NombreManguera', models.CharField(max_length=6, null=True, verbose_name=b'NombreManguera:', blank=True)),
                ('Tanque', models.CharField(max_length=15, null=True, verbose_name=b'Tanque:', blank=True)),
                ('Combustible', models.ForeignKey(verbose_name=b'Id Combustible', to='Procesos.TCombustible')),
                ('Surtidor', models.ForeignKey(verbose_name=b'Id Surtidor', to='Procesos.Surtidor')),
            ],
            options={
                'ordering': ['idManguera'],
                'verbose_name': 'Manguera',
                'verbose_name_plural': 'Mangueras',
            },
        ),
        migrations.CreateModel(
            name='TMovimientoVista',
            fields=[
                ('idMovimientoVista', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('IngresoTransferencia', models.DecimalField(max_digits=15, decimal_places=3)),
                ('IngresoTransferenciaContable', models.DecimalField(max_digits=15, decimal_places=3)),
                ('Motivo', models.CharField(max_length=100, null=True, verbose_name=b'Motivo:', blank=True)),
                ('Observacion', models.CharField(max_length=100, null=True, verbose_name=b'Observacion:', blank=True)),
                ('Punitario', models.DecimalField(default=0, max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idMovimientoVista'],
                'verbose_name': 'Movimiento Vista',
                'verbose_name_plural': 'Movimientos Vista',
            },
        ),
        migrations.CreateModel(
            name='TPagos',
            fields=[
                ('idPago', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('Concepto', models.CharField(max_length=100, null=True, verbose_name=b'Concepto:', blank=True)),
                ('MontoAmortizado', models.DecimalField(max_digits=15, decimal_places=2)),
            ],
            options={
                'ordering': ['idPago'],
                'verbose_name': 'Pago',
                'verbose_name_plural': 'Pagos',
            },
        ),
        migrations.CreateModel(
            name='TReporteDiario',
            fields=[
                ('idReporteDiario', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('Fecha', models.DateTimeField(auto_now=True, verbose_name=b'Fecha:')),
                ('FechaInicial', models.DateField(verbose_name=b'Fecha inicial:')),
                ('FechaFinal', models.DateField(verbose_name=b'Fecha final:')),
                ('Griferos', models.CharField(max_length=250, verbose_name=b'Griferos:')),
                ('DepositoBancos', models.DecimalField(max_digits=15, decimal_places=3)),
                ('SaldoCredito', models.DecimalField(max_digits=15, decimal_places=3)),
                ('SaldoGastos', models.DecimalField(max_digits=15, decimal_places=3)),
                ('Observacion', models.CharField(max_length=300, null=True, verbose_name=b'Observacion:', blank=True)),
                ('Grifo', models.ForeignKey(verbose_name=b'Id Grifo', to='Procesos.Grifo')),
            ],
            options={
                'ordering': ['idReporteDiario'],
                'verbose_name': 'Reporte Diario',
                'verbose_name_plural': 'Reportes Diarios',
            },
        ),
        migrations.CreateModel(
            name='TSaldoCombustible',
            fields=[
                ('idSaldoCombustible', models.AutoField(serialize=False, verbose_name=b'ID:', primary_key=True)),
                ('SaldoActual', models.DecimalField(max_digits=15, decimal_places=3)),
                ('SaldoActualMovContable', models.DecimalField(default=0, max_digits=15, decimal_places=3)),
                ('ReporteDiario', models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario')),
                ('Tanque', models.ForeignKey(verbose_name=b'Tanque', to='Procesos.Tanque')),
            ],
            options={
                'ordering': ['idSaldoCombustible'],
                'verbose_name': 'Saldo Combustible',
                'verbose_name_plural': 'Saldos Combustible',
            },
        ),
        migrations.CreateModel(
            name='TTitular',
            fields=[
                ('idTitular', models.AutoField(serialize=False, verbose_name=b'Id', primary_key=True)),
                ('Nombre', models.CharField(max_length=100, null=True, verbose_name=b'Nombre:', blank=True)),
                ('DocID', models.CharField(max_length=15, null=True, verbose_name=b'Tel\xc3\xa9fono:', blank=True)),
                ('Debito', models.DecimalField(max_digits=15, decimal_places=3)),
                ('Credito', models.DecimalField(max_digits=15, decimal_places=3)),
            ],
            options={
                'ordering': ['idTitular'],
                'verbose_name': 'Titular',
                'verbose_name_plural': 'Titulares',
            },
        ),
        migrations.AddField(
            model_name='tpagos',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tpagos',
            name='Titular',
            field=models.ForeignKey(verbose_name=b'Id Titular', to='Procesos.TTitular'),
        ),
        migrations.AddField(
            model_name='tmovimientovista',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tmovimientovista',
            name='Tanque',
            field=models.ForeignKey(verbose_name=b'Tanque', to='Procesos.Tanque'),
        ),
        migrations.AddField(
            model_name='tmovimientovista',
            name='Titular',
            field=models.ForeignKey(verbose_name=b'Id Titular', to='Procesos.TTitular', null=True),
        ),
        migrations.AddField(
            model_name='tdetalleserafin',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tdetallegastos',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tdetalledescuento',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tdetalledescuento',
            name='Titular',
            field=models.ForeignKey(verbose_name=b'Id Titular', to='Procesos.TTitular'),
        ),
        migrations.AddField(
            model_name='tdetallecreditos',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tdetallecreditos',
            name='Titular',
            field=models.ForeignKey(verbose_name=b'Id Titular', to='Procesos.TTitular'),
        ),
        migrations.AddField(
            model_name='tdeposito',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='tanque',
            name='Combustible',
            field=models.ForeignKey(verbose_name=b'Id Combustible', to='Procesos.TCombustible'),
        ),
        migrations.AddField(
            model_name='tanque',
            name='Grifo',
            field=models.ForeignKey(verbose_name=b'Id Grifo', to='Procesos.Grifo'),
        ),
        migrations.AddField(
            model_name='preciocombustible',
            name='Combustible',
            field=models.ForeignKey(verbose_name=b'Id Combustible', to='Procesos.TCombustible'),
        ),
        migrations.AddField(
            model_name='preciocombustible',
            name='Grifo',
            field=models.ForeignKey(verbose_name=b'Id Grifo', to='Procesos.Grifo'),
        ),
        migrations.AddField(
            model_name='preciocombustible',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
        migrations.AddField(
            model_name='lecturacontometro',
            name='Manguera',
            field=models.ForeignKey(verbose_name=b'Id Manguera', to='Procesos.TManguera'),
        ),
        migrations.AddField(
            model_name='lecturacontometro',
            name='ReporteDiario',
            field=models.ForeignKey(verbose_name=b'Id Reporte', to='Procesos.TReporteDiario'),
        ),
    ]
