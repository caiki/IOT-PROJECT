# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0006_auto_20180209_0923'),
    ]

    operations = [
        migrations.AlterField(
            model_name='tcompra',
            name='TransporteGalon',
            field=models.DecimalField(default=0, max_digits=15, decimal_places=2),
        ),
    ]
