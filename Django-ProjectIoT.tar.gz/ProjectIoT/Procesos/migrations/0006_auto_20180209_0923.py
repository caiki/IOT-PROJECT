# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0005_tcompra'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='tcompra',
            name='IngresoTransferencia',
        ),
        migrations.RemoveField(
            model_name='tcompra',
            name='IngresoTransferenciaContable',
        ),
        migrations.RemoveField(
            model_name='tcompra',
            name='ReporteDiario',
        ),
        migrations.RemoveField(
            model_name='tcompra',
            name='Tanque',
        ),
        migrations.AddField(
            model_name='tcompra',
            name='idMovimientoVista',
            field=models.ForeignKey(verbose_name=b'Movimiento Vista', to='Procesos.TMovimientoVista', null=True),
        ),
        migrations.AlterField(
            model_name='tcompra',
            name='FechaPago',
            field=models.DateField(verbose_name=b'Fecha Pago:'),
        ),
        migrations.AlterField(
            model_name='tcompra',
            name='Observacion',
            field=models.CharField(max_length=250, null=True, verbose_name=b'Observacion', blank=True),
        ),
    ]
