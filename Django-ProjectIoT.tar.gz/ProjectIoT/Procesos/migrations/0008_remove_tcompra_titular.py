# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0007_auto_20180209_0938'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='tcompra',
            name='Titular',
        ),
    ]
