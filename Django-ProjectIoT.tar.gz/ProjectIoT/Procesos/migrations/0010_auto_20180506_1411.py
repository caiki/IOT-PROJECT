# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Procesos', '0009_theart'),
    ]

    operations = [
        migrations.AlterField(
            model_name='theart',
            name='FechaTiempo',
            field=models.DateTimeField(verbose_name=b'FechaTiempo:'),
        ),
    ]
